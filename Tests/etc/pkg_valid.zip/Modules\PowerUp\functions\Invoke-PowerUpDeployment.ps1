﻿function Invoke-PowerUpDeployment {
<#
	.SYNOPSIS
		Deploys PowerUp package to the specified location
	
	.DESCRIPTION
		A detailed description of the Invoke-PowerUpPackage function.
	
	.EXAMPLE
				PS C:\> Invoke-PowerUpPackage
	
	.NOTES
		Additional information about the function.
#>
	
	[CmdletBinding()]
	Param (
		[string]$PackageFile,
		[string]$SqlInstance,
		[string]$Database,
		[ValidateSet('SingleTransaction', 'TransactionPerScript', 'NoTransaction')]
		[string]$DeploymentMethod = 'NoTransaction',
		[int]$ConnectionTimeout,
		[switch]$Encrypt,
		[pscredential]$Credential,
		[string]$UserName,
		[securestring]$Password,
		[string]$LogToTable,
		[switch]$Silent,
		[hashtable]$Variables
	)
	
	#Stop on error
	$ErrorActionPreference = 'Stop'
	
	Write-Verbose "Loading package information"
	#Get package object from the json file
	if (!$PackageFile) { $PackageFile = ".\PowerUp.package.json" }
	if (!(Test-Path $PackageFile)) {
		Write-Error "Package file $PackageFile not found. Aborting deployment."
		return
	}
	else {
		$PackageFile = Get-Item $PackageFile
	}
	$package = [PowerUpPackage]::FromFile($PackageFile.FullName)
	
	#Read config file 
	$configPath = Join-Path $PackageFile.DirectoryName $package.ConfigurationFile
	if (!$package.ConfigurationFile -or !(Test-Path $configPath)) {
		Write-Error "Configuration file cannot be found. The package is corrupted."
		return
	}
	$config = Get-PowerUpConfig $configPath
	
	#Join variables from config and parameters
	$runtimeVariables = @{ }
	if ($Variables) {
		$runtimeVariables += $Variables
	}
	if ($config.Variables) {
		foreach ($variable in $config.Variables.psobject.Properties.Name) {
			if ($variable -notin $runtimeVariables.Keys) {
				$runtimeVariables += @{
					$variable  = $config.Variables.$variable
				}
			}
		}
	}
	
	#Replace tokens if any
	foreach ($property in $config.psobject.Properties.Name | Where-Object { $_ -ne 'Variables' }) {
		$config.$property = Replace-VariableTokens $config.$property $runtimeVariables
	}
	
	#Apply overrides if any
	foreach ($key in ($PSBoundParameters.Keys | Where-Object { $_ -ne 'Variables' })) {
		if ($key -in $config.psobject.Properties.Name) {
			$config.$key = Replace-VariableTokens $PSBoundParameters[$key] $runtimeVariables
		}
	}
	
	#Apply default values if not set
	if (!$config.ApplicationName) { $config.ApplicationName = 'PowerUp' }
	if (!$config.SqlInstance) { $config.SqlInstance = 'localhost' }
	if (!$config.ConnectionTimeout) { $config.ConnectionTimeout = 30 }
	if (!$config.LogToTable) { $config.LogToTable = 'dbo.SchemaVersions' }
	
	
	#Build connection string
	$CSBuilder = New-Object -TypeName System.Data.SqlClient.SqlConnectionStringBuilder
	$CSBuilder["Server"] = $config.SqlInstance
	if ($config.Database) { $CSBuilder["Database"] = $config.Database }
	if ($config.Encrypt) { $CSBuilder["Encrypt"] = $true }
	$CSBuilder["Connection Timeout"] = $config.ConnectionTimeout
	
	if ($config.Credential) {
		$CSBuilder["Trusted_Connection"] = $false
		$CSBuilder["User ID"] = $config.Credential.UserName
		$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($config.Credential.Password)
		$CSBuilder["Password"] = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
	}
	elseif ($config.Username) {
		$CSBuilder["Trusted_Connection"] = $false
		$CSBuilder["User ID"] = $config.UserName
		if ($config.Password.GetType() -eq [securestring]) {
			$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($config.Password)
			$CSBuilder["Password"] = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
		}
		else {
			$CSBuilder["Password"] = $config.Password
		}
	}
	else {
		$CSBuilder["Integrated Security"] = $true
	}
	
	$CSBuilder["Application Name"] = $config.ApplicationName
	
	
	$scriptCollection = @()
	$scriptRoot = Join-Path $PackageFile.DirectoryName $package.ScriptDirectory
	
	# Get contents of the script files
	foreach ($build in $package.builds) {
		foreach ($script in $build.scripts) {
			# Replace tokens in the scripts
			$scriptPath = Join-Path $scriptRoot $script.PackagePath
			$scriptContent = Replace-VariableTokens (Get-Content $scriptPath -Raw)
			$scriptCollection += [DbUp.Engine.SqlScript]::new($script.PackagePath, $scriptContent)
		}
	}
	$scripts = Get-DeploymentScript $package
	
	#Build dbUp object
	$dbUp = [DbUp.DeployChanges]::To
	$dbUp = [SqlServerExtensions]::SqlDatabase($dbUp, $CSBuilder.ToString())
	
	#Add deployment scripts to the object
	$dbUp = [StandardExtensions]::WithScripts($dbUp, $scriptCollection)
	
	
	if ($config.DeploymentMethod -eq 'SingleTransaction') {
		$dbUp = [StandardExtensions]::WithTransaction($dbUp)
	}
	elseif ($config.DeploymentMethod -eq 'TransactionPerScript') {
		$dbUp = [StandardExtensions]::WithTransactionPerScript($dbUp)
	}
	
	if (!($config.Silent)) {
		$dbUp = [StandardExtensions]::LogToConsole($dbUp)
		#$dbUp = [StandardExtensions]::LogTo($dbUp, (New-Object PowerUpConsoleLog))
		$dbUp = [StandardExtensions]::LogScriptOutput($dbUp)
	}
	
	#$dbUp = [StandardExtensions]::WithScriptsFromFileSystem($dbUp, $scriptPath)
	# Configure logging
	if ($config.LogToTable) {
		$table = $config.LogToTable.Split('.')
		if (($table | Measure-Object).Count -gt 2) {
			throw 'Incorrect table name - use the following syntax: schema.table'
		}
		elseif (($table | Measure-Object).Count -eq 2) {
			$tableName = $table[1]
			$schemaName = $table[0]
		}
		elseif (($table | Measure-Object).Count -eq 1) {
			$tableName = $table[0]
			$schemaName = 'dbo'
		}
		else {
			throw 'No table name specified'
		}
		
		$dbUp = [SqlServerExtensions]::JournalToSqlTable($dbUp, $schemaName, $tableName)
	}
	
	#Build and Upgrade
	$build = $dbUp.Build()
	$upgradeResult = $build.PerformUpgrade()
	$upgradeResult
	
	
	#TODO: Place script here
}
