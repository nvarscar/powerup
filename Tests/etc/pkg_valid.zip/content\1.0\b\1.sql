
select 1/0