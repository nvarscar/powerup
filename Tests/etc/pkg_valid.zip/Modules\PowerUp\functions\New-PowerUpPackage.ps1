﻿<#
	.SYNOPSIS
		Creates a new deployment package from specified set of scripts
	
	.DESCRIPTION
		Creates a new zip package which would contain a set of deployment scripts
	
	.PARAMETER ScriptPath
		A description of the ScriptPath parameter.
	
	.PARAMETER Name
		Output package name. Can be full file path or just a file name.
	
	.PARAMETER Build
		A description of the Build parameter.
	
	.PARAMETER ApplicationName
		A description of the ApplicationName parameter.
	
	.PARAMETER DeploymentMethod
		A description of the DeploymentMethod parameter.
	
	.PARAMETER UserName
		A description of the UserName parameter.
	
	.PARAMETER Password
		A description of the Password parameter.
	
	.PARAMETER ConnectionTimeout
		A description of the ConnectionTimeout parameter.
	
	.PARAMETER Encrypt
		A description of the Encrypt parameter.
	
	.PARAMETER Force
		A description of the Force parameter.
	
	.PARAMETER ConfigurationFile
		A description of the ConfigurationFile parameter.
	
	.PARAMETER Version
		A description of the Version parameter.
	
	.EXAMPLE
		PS C:\> New-PowerUpPackage -ScriptPath $value1 -Name 'Value2'
	
	.NOTES
		Additional information about the function.
#>
function New-PowerUpPackage {
	[CmdletBinding(DefaultParameterSetName = 'Default',
				   SupportsShouldProcess = $true)]
	param
	(
		[Parameter(Mandatory = $true,
				   ValueFromPipeline = $true,
				   Position = 1)]
		[object[]]$ScriptPath,
		[Parameter(Mandatory = $false,
				   Position = 2)]
		[Alias('FileName')]
		[string]$Name = (Split-Path (Get-Location) -Leaf),
		[Parameter(ParameterSetName = 'Default')]
		[string]$Build,
		[Parameter(ParameterSetName = 'Default')]
		[string]$ApplicationName = 'PowerUp',
		[Parameter(ParameterSetName = 'Default')]
		[ValidateSet('SingleTransaction', 'TransactionPerScript', 'NoTransaction')]
		[string]$DeploymentMethod = 'NoTransaction',
		[Parameter(ParameterSetName = 'Default')]
		[string]$UserName,
		[Parameter(ParameterSetName = 'Default')]
		[securestring]$Password,
		[Parameter(ParameterSetName = 'Default')]
		[int]$ConnectionTimeout = 30,
		[Parameter(ParameterSetName = 'Default')]
		[switch]$Encrypt,
		[switch]$Force,
		[Parameter(ParameterSetName = 'Config')]
		[Alias('Config')]
		[string]$ConfigurationFile
	)
	
	begin {
		$currentDate = Get-Date
		if (!$Build) {
			$Build = [string]$currentDate.Year + '.' + [string]$currentDate.Month + '.' + [string]$currentDate.Day + '.' + [string]$currentDate.Hour
		}
		
		if ($Name.EndsWith('.zip') -eq $false) {
			$Name = "$Name.zip"
		}
		
		#Create temp folder
		
		$tempFolder = "PowerUpBuild" + [string](Get-Random(99999))
		$tempPath = [System.IO.Path]::GetTempPath()
		$tempFolder = New-Item (Join-Path $tempPath $tempFolder) -ItemType Directory
		
		if ($ConfigurationFile -and (Test-Path $ConfigurationFile) -eq $false) {
			Write-Error -Message 'Configuration file does not exist'
			$failed = $true
			return
		}
		#Generate a config object
		Write-Verbose "Loading config $ConfigurationFile"
		$config = Get-PowerUpConfig $ConfigurationFile
		
		#Apply overrides if any
		foreach ($key in ($PSBoundParameters.Keys | Where-Object { $_ -ne 'Variables' })) {
			if ($key -in $config.psobject.Properties.Name) {
				Write-Verbose "Overriding config property $key"
				$config.$key = $PSBoundParameters[$key]
			}
		}
		
		#Create a package object
		$package = [PowerUpPackage]::new()
		
		#Create new build
		$currentBuild = $package.NewBuild($config.Build)
		Write-Verbose "Current build $($currentBuild.build)"
		
		#Create scripts array
		$scripts = @()
	}
	process {
		if (!$failed) {
			foreach ($scriptItem in $ScriptPath) {
				if (!(Test-Path $scriptItem)) {
					Write-Error -Message "The following path is not valid: $ScriptPath"
					$failed = $true
					return
				}
				foreach ($currentItem in (Get-Item $scriptItem)) {
					if ($currentItem.PSIsContainer) {
						$replacePath = $currentItem.FullName
					}
					else {
						$replacePath = $currentItem.DirectoryName
					}
					$items = Get-ChildItem $currentItem -Recurse -File
					foreach ($i in $items) {
						$currentBuild.NewScript($i.FullName, $replacePath)
					}
				}
			}
		}
	}
	end {
		if (!$failed -and $pscmdlet.ShouldProcess($package, "Generate a package file")) {
			#Copy package contents to the temp folder
			Write-Verbose "Copying deployment file $($package.DeploySource)"
			Copy-Item -Path $package.DeploySource -Destination (Join-Path $tempFolder $package.DeployScript)
			if ($package.PreDeploySource) {
				Write-Verbose "Copying pre-deployment file $($package.PreDeploySource)"
				Copy-Item -Path $package.PreDeploySource -Destination (Join-Path $tempFolder $package.PreDeployScript)
			}
			if ($package.PostDeploySource) {
				Write-Verbose "Copying post-deployment file $($package.PostDeploySource)"
				Copy-Item -Path $package.PostDeploySource -Destination (Join-Path $tempFolder $package.PostDeployScript)
			}
			#Write-Verbose "Copying deployment library $($package.DeploymentLibrary)"
			#Copy-Item -Path $package.DeploymentLibrary -Destination $tempFolder
			$scriptDir = New-Item (Join-Path $tempFolder $package.ScriptDirectory) -Type Directory
			foreach ($b in $package.builds) {
				Write-Verbose "Processing build $b"
				foreach ($script in $b.scripts) {
					$destination = Join-Path $scriptDir $script.packagePath
					$destFolder = Split-Path $destination -Parent
					if (-not (Test-Path $destFolder)) {
						Write-Verbose "Creating folder $destFolder"
						$null = New-Item -Path $destFolder -Type Directory
					}
					Write-Verbose "Copying file $($script.sourcePath)"
					Copy-Item -Path $script.sourcePath -Destination $destination
				}
			}
			
			$configPath = Join-Path $tempFolder $package.ConfigurationFile
			Write-Verbose "Writing configuration file $configPath"
			$config | ConvertTo-Json -Depth 2 | Out-File $configPath
			
			$packagePath = Join-Path $tempFolder $package.PackageFile
			Write-Verbose "Writing package file $packagePath"
			$package.SaveToFile($packagePath)
			
			#Copy module into the archive
			$moduleSrc = (Get-Module PowerUp).ModuleBase
			$moduleDir = New-Item (Join-Path $tempFolder "Modules") -ItemType Directory
			Write-Verbose "Copying module files into the package"
			Copy-Item $moduleSrc $moduleDir -Recurse -Force
			
			Write-Verbose "Creating archive file $Name"
			Compress-Archive "$tempFolder\*" -DestinationPath $Name -Force:$Force
			
		}
		Write-Verbose "Removing temporary folder $tempFolder"
		Remove-Item $tempFolder -Recurse -Force
	}
}
