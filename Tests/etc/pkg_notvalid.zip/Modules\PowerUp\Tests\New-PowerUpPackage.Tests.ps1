﻿$commandName = $MyInvocation.MyCommand.Name.Replace(".Tests.ps1", "")
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$sut = (Split-Path -Leaf $MyInvocation.MyCommand.Path) -replace '\.Tests\.', '.'

$packagePath = '.\etc\PowerUpTest.zip'
Describe "$commandName tests" {	
	
	function Get-ArchiveItems {
		param ([Parameter(Mandatory)]
			[string]$Archive)
		function recurse-items {
			param ([object]$items)
			
			foreach ($item in $items) {
				$item
				$folder = $item.GetFolder
				if ($folder) {
					recurse-items $folder.Items()
				}
			}
		}
		
		$Archive = Resolve-Path $Archive
		$shellApp = New-Object -ComObject shell.application
		$zipFile = $shellApp.NameSpace($Archive)
		recurse-items $zipFile.Items() | ForEach-Object {
			$zipPath = $_.Path.Replace($Archive + [System.IO.Path]::DirectorySeparatorChar, '')
			$level = ($zipPath.Split([string][System.IO.Path]::DirectorySeparatorChar)).Count
			$_ | Add-Member @{ Archive = $Archive; Level = $level; Path = $zipPath } -PassThru -Force
		} | Sort-Object Level, Name | Select-Object * -ExcludeProperty Application, Parent, GetLink, GetFolder, Level
	}
	
	BeforeAll {
		if (Test-Path $packagePath) { Remove-Item $packagePath -Force }
	}
	AfterAll {
		if (Test-Path $packagePath) { Remove-Item $packagePath -Force }
	}
	It "returns error when path does not exist" {
		try {
			$result = New-PowerUpPackage -ScriptPath 'asduwheiruwnfelwefo\sdfpoijfdsf.sps' -ErrorVariable errorResult 2>$null
		}
		catch {}
		$errorResult.Exception.Message | Should BeLike 'The following path is not valid*'
	}
	It "returns error when config file does not exist" {
		try {
			$result = New-PowerUpPackage -ScriptPath '.' -Config 'asduwheiruwnfelwefo\sdfpoijfdsf.sps' -ErrorVariable errorResult 2>$null
		}
		catch {}
		$errorResult.Exception.Message | Should Be 'Configuration file does not exist'
	}
	It "should create a package file" {
		{ $null = New-PowerUpPackage -ScriptPath '.\etc\query1.sql' -Name $packagePath }  | Should Not Throw
		Test-Path $packagePath | Should Be $true
	}
	It "should contain query files" {
		$results = Get-ArchiveItems $packagePath
		$results | Where-Object Name -eq 'query1.sql' | Should Not Be $null
	}
	It "should contain module files" {
		$results = Get-ArchiveItems $packagePath
		$results | Where-Object Path -eq 'Modules\PowerUp\PowerUp.psd1' | Should Not Be $null
		$results | Where-Object Path -eq 'Modules\PowerUp\bin\DbUp.dll' | Should Not Be $null
	}
	It "should contain config files" {
		$results = Get-ArchiveItems $packagePath
		$results | Where-Object Path -eq 'PowerUp.config.json' | Should Not Be $null
		$results | Where-Object Path -eq 'PowerUp.package.json' | Should Not Be $null
	}
}
