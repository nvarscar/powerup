CREATE TABLE dbo.a (a int)
GO
CREATE TABLE dbo.b (a int)
